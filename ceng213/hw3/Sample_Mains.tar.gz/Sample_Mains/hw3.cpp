#include "hw3.h"

// #include <iomanip> // delete later

#define EMPTY_PAIR (std::make_pair(EMPTY, EMPTY))
#define DELETED_PAIR (std::make_pair (DELETED, DELETED))

AccessControl::AccessControl (int table1Size, int table2Size)
{
	n_regUsers = n_activeUsers = 0;
	regUsers.resize (table1Size, EMPTY_PAIR);
	activeUsers.resize (table2Size, EMPTY);
}

AccessControl::~AccessControl () {}

float AccessControl::printPasswords ()
{
	// for (size_t i = 0; i < regUsers.size (); ++ i)
	// {
	// 	std::cout << std::setw(2) << i << ": " << std::setw(20) << regUsers[i].first << " " << std::setw(20) << regUsers[i].second << std::endl;
	// }
	for (size_t i = 0; i < regUsers.size (); ++ i)
	{
		std::cout << regUsers[i].first << " " << regUsers[i].second << std::endl;
	}

	return n_regUsers*1.0/regUsers.size ();
}

float AccessControl::printActiveUsers ()
{

	// for (size_t i = 0; i < activeUsers.size (); ++ i)
	// {
	// 	std::cout << i << ": " << std::setw (20) << activeUsers[i] << std::endl;
	// }
	for (size_t i = 0; i < activeUsers.size (); ++ i)
	{
		std::cout << activeUsers[i] << std::endl;
	}
	return n_activeUsers*1.0/activeUsers.size ();
}

std::string AccessControl::getPassword (std::string username)
{
	std::string pass = "";
	for (int i = 0; i < (int)regUsers.size (); ++ i)
	{
		int index = hashFunction (username, regUsers.size (), i);
		if (regUsers[index].first == username)
			pass = regUsers[index].second;
	}
	return pass;
}

int AccessControl::addUser (std::string username, std::string pass)
{
	int tableSize = (int)regUsers.size ();
	int ret = 0;
	for (int i = 0; i < tableSize; ++ i)
	{
		int index = hashFunction (username, tableSize, i);
		if (regUsers[index].first == EMPTY || regUsers[index].first == DELETED)
		{
			regUsers[index] = make_pair (username, pass);
			++ n_regUsers;
			ret = 1;
			break;
		}
		if (regUsers[index].first == username)
		{
			break;
		}
	}

	updateSize ();

	return ret;
}

int AccessControl::updateSize ()
{
	// std::cout << "updateSize ()\n" << std::flush;
	// std::cout << n_regUsers << " " << regUsers.size () 
	// << " " << n_regUsers*1.0/regUsers.size () << std:: endl << std::flush;


	int ret = 0;

	if (n_regUsers*1.0/regUsers.size () > MAX_LOAD_FACTOR)
	{
		// std::cout << " regUsers update\n" << std::flush;
		std::vector <std::pair <std::string, std::string> > temp;
		int newSize, oldSize = regUsers.size ();
		for (newSize = 2 * oldSize; !prime (newSize); ++ newSize);
		regUsers.resize (newSize, EMPTY_PAIR);
		// temp.resize (newSize, EMPTY_PAIR);
		for (int i = 0; i < oldSize; ++ i)
		{
			// for (int k = 0; k < oldSize; ++ k)
			// {
				// int super_index = hashFunction (regUsers[i].first, oldSize, k);
				int super_index = i;
				if (regUsers[super_index].first != DELETED && regUsers[super_index].first != EMPTY)
				{
					// std::cout << super_index << " " << regUsers[super_index].first << "\n";
					// std::pair <std::string, std::string> t = regUsers[i];
					// do not use addUser (), because there could be users with old
					// and new passwords
					int flag = 1;
					for (int j = 0; j < regUsers.size (); ++ j)
					{
						int index = hashFunction (regUsers[super_index].first, regUsers.size (), j);
						if (regUsers[index].first == EMPTY || regUsers[index].first == DELETED)
						{
							// std::cout << "  j = " << j << std::endl;
							regUsers[index] = regUsers[super_index];
							if (index == super_index)
								flag = 0;
							break;
						}
					}
					if (flag) regUsers[super_index] = EMPTY_PAIR;
				// }
			}
		}
		++ ret;
	}

	if (n_activeUsers*1.0/activeUsers.size () > MAX_LOAD_FACTOR)
	{
		// std::cout << " active update\n" << std::flush;
		int newSize, oldSize = activeUsers.size ();
		for (newSize = 2 * oldSize; !prime (newSize); ++ newSize);
		activeUsers.resize (newSize, EMPTY);

		for (int i = 0; i < oldSize; ++ i)
		{
			if (activeUsers[i] != DELETED && activeUsers[i] != EMPTY)
			{
				std::string t = activeUsers[i];
				activeUsers[i] = EMPTY;
				-- n_activeUsers;
				login (t, getPassword (t));
			}
		}
		++ ret;
	}

	return ret;
}

int AccessControl::addUsers (std::string filePath)
{
	std::ifstream fin (filePath.c_str ());
	std::string username, password;
	int ret = 0;
	while (fin >> username >> password)
	{
		ret += addUser (username, password);
	}
	return ret;
}

int AccessControl::delUser (std::string username, std::vector<std::string>& oldPasswords)
{
	int ret = 0;
	for (int i = 0; i < regUsers.size (); ++ i)
	{
		int index = hashFunction (username, regUsers.size (), i);

		if (regUsers[index].first == username)
		{
			oldPasswords.push_back (regUsers[index].second);
			regUsers[index] = DELETED_PAIR;
			-- n_regUsers;
			ret = 1;
		}
	}
	return ret;
}

int AccessControl::changePass (std::string username, std::string oldpass, std::string newpass)
{
	// std::cout << "hello\n" << std::flush;
	int i, ok = 0;
	std::string pass = "";
	for (i = 0; i < (int)regUsers.size (); ++ i)
	{
		// std::cout << "i = " << i << "\n";
		int index = hashFunction (username, regUsers.size (), i);
		// std::cout << "  index = " << index << std::endl;
		if (regUsers[index].first == username ) pass = regUsers[index].second;
		// std::cout << "oldpass = " << pass << std::endl;
		if (regUsers[index] == EMPTY_PAIR && pass == oldpass)
		{
			regUsers[index] = make_pair (username, newpass);
			++ n_regUsers;
			updateSize ();
			return 1;
		}
	}
	return 0;
}

int AccessControl::login (std::string username, std::string pass)
{
	std::string real_pass = getPassword (username);
	if (pass == real_pass)
	{
		for (int i = 0; i < (int)activeUsers.size (); ++ i)
		{
			int index = hashFunction (username, activeUsers.size (), i);
			if (activeUsers[index] == username) return 0;
			if (activeUsers[index] == EMPTY || activeUsers[index] == DELETED)
			{
				activeUsers[index] = username;
				++ n_activeUsers;
				updateSize ();
				return 1;
			}
		}
	}

	return 0;
}

int AccessControl::logout (std::string username)
{
	for (int i = 0; i < activeUsers.size (); ++ i)
	{
		int index = hashFunction (username, activeUsers.size (), i);
		if (activeUsers[index] == username)
		{
			activeUsers[index] = DELETED;
			-- n_activeUsers;
			return 1;
		}
	}
	return 0;
}